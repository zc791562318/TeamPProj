﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

public partial class 管理员界面 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    
protected void Button4_Click(object sender, EventArgs e)
{
    Response.Redirect("管理员界面.aspx");
}
protected void Button3_Click(object sender, EventArgs e)
{
    Response.Redirect("图片管理.aspx");
}
protected void Button2_Click(object sender, EventArgs e)
{
    Response.Redirect("账号管理.aspx");
}
protected void Button5_Click(object sender, EventArgs e)
{
    Response.Redirect("登陆界面.aspx");
}
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;

/// <summary>
/// User 的摘要说明
/// </summary>
public class User
{
    public User()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public string userid;
    public string username;
    public string userpwd;
    public  bool ifLogin(User obj)
    {
        bool blRet = true;
        string strSQL = "select * from Users where ename='" + obj.username + "' "
            + " and password='" + obj.userpwd + "'";
        DataTable dt = DBOper.execQueryBySQLText(strSQL);
        try
        {
            if (dt.Rows.Count > 0)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }
        }
        catch
        {
            blRet = false;
        }
        return blRet;
    }

    public  DataTable selectDataTable(User obj)
    {
        string strSQL = "select * from Users where 1=1 ";
        if (obj.username != "" && obj.username != null)
            strSQL = strSQL + "and ename='" + obj.username + "'";

        DataTable dt = DBOper.execQueryBySQLText(strSQL);

        return dt;
    }

    public static int insertRecord(User obj)
    {
        string strSQL = "insert into Users(eno,ename,password) values('" + obj.userid + "','" + obj.username + "','" + obj.userpwd + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int deleteRecord(User obj)
    {
        string strSQL = "delete from Users where eno='" + obj.userid + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int updateRecord(User obj)
    {
        string strSQL = "update Users set ename='" + obj.username + "' where eno='" + obj.userid + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
}
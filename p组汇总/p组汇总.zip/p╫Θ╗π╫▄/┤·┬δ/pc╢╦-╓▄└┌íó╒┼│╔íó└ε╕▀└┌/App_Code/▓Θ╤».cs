﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;

/// <summary>
/// User 的摘要说明
/// </summary>
public class 查询
{
    public 查询()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public string doc_no;
    public string doc_name;
    public string doc_date;
    public string doc_seid;
    public bool ifLogin(查询 obj)
    {
        bool blRet = true;
        string strSQL = "select * from document where doc_name='" + obj.doc_name + "' "
            + " and doc_no='" + obj.doc_no + "'";
        DataTable dt = DBOper.execQueryBySQLText(strSQL);
        try
        {
            if (dt.Rows.Count > 0)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }
        }
        catch
        {
            blRet = false;
        }
        return blRet;
    }

    public DataTable selectDataTable(查询 obj)
    {
        string strSQL = "select * from document where 1=1 ";
        if (obj.doc_name != "" && obj.doc_name != null)
        {
            strSQL = strSQL + "and doc_name='" + obj.doc_name + "'";
        }
            if (obj.doc_no != "" && obj.doc_no != null)
            {

                strSQL = strSQL + "and doc_no='" + obj.doc_no + "'";
            }
                if (obj.doc_seid != "" && obj.doc_seid != null)
                {
                    strSQL = strSQL + "and doc_seid='" + obj.doc_seid + "'";
                }
                    if (obj.doc_date != "" && obj.doc_date != null)
                    {
                        strSQL = strSQL + "and doc_date='" + obj.doc_date + "'";
                    }
                    
                
    
            
        
        DataTable dt = DBOper.execQueryBySQLText(strSQL);

        return dt;
    }

    public static int insertRecord(查询 obj)
    {
        string strSQL = "insert into document(doc_no,doc_name,doc_seid) values('" + obj.doc_no + "','" + obj.doc_name + "','" + obj.doc_seid + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int deleteRecord(查询 obj)
    {
        string strSQL = "delete from document where doc_no='" + obj.doc_no + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int updateRecord(查询 obj)
    {
        string strSQL = "update documnet set doc_name='" + obj.doc_name + "' where doc_no='" + obj.doc_name + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
}
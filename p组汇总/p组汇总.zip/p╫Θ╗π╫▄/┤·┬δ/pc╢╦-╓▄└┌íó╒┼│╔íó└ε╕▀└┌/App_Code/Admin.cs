﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// User 的摘要说明
/// </summary>
public class Admin
{
    public Admin()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public string ad_no;
    public string ad_name;
    public string ad_pwd;

    public bool ifLogin(Admin obj)
    {
        bool blRet = true;
        string strSQL = "select * from admin where ad_name='" + obj.ad_name + "' "
            + " and password='"+obj.ad_pwd+"'";
        DataTable dt = DBOper.execQueryBySQLText(strSQL);
        try
        {
            if (dt.Rows.Count > 0)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }
        }
        catch
        {
            blRet = false;
        }
        return blRet;
    }

    public static DataTable selectDataTable(Admin obj)
    {
        string strSQL = "select * from admin where 1=1 ";
        if (obj.ad_name != "" && obj.ad_name != null)
            strSQL = strSQL + "and ad_name='" + obj.ad_name + "'";

        DataTable dt = DBOper.execQueryBySQLText(strSQL);

        return dt;
    }

    public static int insertRecord(Admin obj)
    {
        string strSQL = "insert into admin(ad_no,ad_name,password) values('"+obj.ad_no+"','"+obj.ad_name+"','"+obj.ad_pwd +"'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int deleteRecord(Admin obj)
    {
        string strSQL = "delete from admin where ad_name='"+ obj.ad_name + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int updateRecord(Admin obj)
    {
        string strSQL = "update admin set ad_name='" + obj.ad_name + "' where ad_no='" + obj.ad_no + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
}
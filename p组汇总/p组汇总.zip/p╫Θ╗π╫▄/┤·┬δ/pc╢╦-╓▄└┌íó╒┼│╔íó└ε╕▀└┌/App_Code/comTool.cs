﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// comTool 的摘要说明
/// </summary>
public  class comTool
{
	public comTool()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public static void Alert(string msg)
    {
        System.Web.HttpContext.Current.Response.Write("<script>alert('" + msg + "');</script>");
    }
    public static void Redirect(string reUrl)
    {
        System.Web.HttpContext.Current.Response.Write("<script>location.href='" + reUrl + "';</script>");
    }
}
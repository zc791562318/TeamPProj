﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// 图片管理 的摘要说明
/// </summary>
public class 图片管理
{
	public 图片管理()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public string doc_no;
    public string tno;
    public string id;
    public bool ifLogin(图片管理 obj)
    {
        bool blRet = true;
        string strSQL = "select * from T_imgs where doc_no='" + obj.doc_no + "' " + " and page='" + obj.tno + "'";
        DataTable dt = DBOper.execQueryBySQLText(strSQL);
        try
        {
            if (dt.Rows.Count > 0)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }
        }
        catch
        {
            blRet = false;
        }
        return blRet;
    }

    public DataTable selectDataTable(图片管理 obj)
    {
        string strSQL = "select * from T_imgs where 1=1 ";
        if (obj.doc_no != "" && obj.doc_no != null)
        {
            strSQL = strSQL + "and doc_no='" + obj.doc_no + "'";
        }
        if (obj.tno != "" && obj.tno != null)
        {

            strSQL = strSQL + "and page='" + obj.tno + "'";
        }
        DataTable dt = DBOper.execQueryBySQLText(strSQL);

        return dt;
    }

    public static int insertRecord(图片管理 obj)
    {
        string strSQL = "insert into T_imgs(doc_no,page) values('" + obj.doc_no + "','" + obj.tno + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int deleteRecord(图片管理 obj)
    {
        string strSQL = "delete from T_imgs where img_id='" + obj.id + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int updateRecord(图片管理 obj)
    {
        string strSQL = "update T_imgs set doc_no='" + obj.doc_no + "' where page='" + obj.tno + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
}
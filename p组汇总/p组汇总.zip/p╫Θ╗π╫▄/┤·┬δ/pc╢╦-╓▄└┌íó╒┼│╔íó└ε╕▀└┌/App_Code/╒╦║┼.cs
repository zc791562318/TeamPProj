﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;

/// <summary>
/// User 的摘要说明
/// </summary>
public class 账号
{
    public 账号()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public string uno;
    public string uname;
    public string upassword;
    public bool ifLogin(账号 obj)
    {
        bool blRet = true;
        string strSQL = "select * from Users where eno='" + obj.uno + "' "   + " and ename='" + obj.uname + "'";
        DataTable dt = DBOper.execQueryBySQLText(strSQL);
        try
        {
            if (dt.Rows.Count > 0)
            {
                blRet = true;
            }
            else
            {
                blRet = false;
            }
        }
        catch
        {
            blRet = false;
        }
        return blRet;
    }

    public DataTable selectDataTable(账号 obj)
    {
        string strSQL = "select * from Users where 1=1 ";
        if (obj.uno != "" && obj.uno != null)
        {
            strSQL = strSQL + "and eno='" + obj.uno + "'";
        }
            if (obj.uname != "" && obj.uname != null)
            {

                strSQL = strSQL + "and ename='" + obj.uname + "'";
            }
                if (obj.upassword != "" && obj.upassword != null)
                {
                    strSQL = strSQL + "and password='" + obj.upassword + "'";
                }
                                   
        DataTable dt = DBOper.execQueryBySQLText(strSQL);

        return dt;
    }

    public static int insertRecord(账号 obj)
    {
        string strSQL = "insert into Users(eno,ename,password) values('" + obj.uno + "','" + obj.uname + "','" + obj.upassword + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int deleteRecord(账号 obj)
    {
        string strSQL = "delete from Users where eno='" + obj.uno + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
    public static int updateRecord(账号 obj)
    {
        string strSQL = "update Users set ename='" + obj.uname + "' where eno='" + obj.uname + "'";
        int iRet = DBOper.execNonQueryBySQLText(strSQL);
        return iRet;
    }
}
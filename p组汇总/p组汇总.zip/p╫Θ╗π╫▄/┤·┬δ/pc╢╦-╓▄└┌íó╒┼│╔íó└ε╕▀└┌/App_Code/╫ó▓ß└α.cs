﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;

/// <summary>
/// 注册类 的摘要说明
/// </summary>
public class 注册类
{
	public 注册类()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public string username;
    public string userid;
    public string password;
    public bool insert(注册类 obj)
    {
        username = obj.username;
        userid = obj.userid;
        password = obj.password;
        string str_provider = "Provider=Microsoft.Jet.OLEDB.4.0;";
        string str_source = "Data Source=F:\\企业文档管理系统P组\\App_Data\\数据库.mdb";
        string str_connection = str_provider + str_source;
        string str_sql = "insert into [Users]([eno],[ename],[password]) values('"+ userid +"','"+ username +"','"+ password +"')";
         string strsql = "SELECT password from Users where eno='" + userid + "'";
        OleDbConnection cnn = new OleDbConnection(str_connection);
        cnn.Open();     
         OleDbCommand cNd = new OleDbCommand(strsql, cnn);
          OleDbDataReader datar;
           datar = cNd.ExecuteReader();
           if (!datar.Read())
           { //return false; 
               OleDbCommand cmd = new OleDbCommand(str_sql, cnn);
               cmd.ExecuteNonQuery();
               cnn.Close();
               return true;
               
            //   OleDbCommand cnd = new OleDbCommand(strsql, cnn);
             //  OleDbDataReader datr;
            //   datr = cnd.ExecuteReader();

            //   if (datr.Read())
             //  {
             //      string pass = datar["password"].ToString();
             //      if (pass != null) return true;
             //      else return false;
           //    }
             //  else return false;

           }

           else return false;
          

      
    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btnN_Click(object sender, EventArgs e)
    {
        System.Web.HttpContext.Current.Response.Write("<script>location.href='注册界面.aspx';</script>");
        //Response.Redirect("zhuce.aspx");
        
    }
    protected void 员工登录_Click(object sender, EventArgs e)
    {
        User obj = new User();
        obj.username = textbox1.Text;
        obj.userpwd = textbox2.Text;
        if (obj.ifLogin(obj))
        {
            comTool.Redirect("用户界面.aspx");
        }
        else
        {
            comTool.Alert("用户名或密码错误！");
        }
    }
    protected void 管理员登录_Click(object sender, EventArgs e)
    {
        Admin obj = new Admin();
        obj.ad_name = textbox1.Text;
        obj.ad_pwd = textbox2.Text;
        if (obj.ifLogin(obj))
        {
            Response.Redirect("管理员界面.aspx");
        }
    }
}
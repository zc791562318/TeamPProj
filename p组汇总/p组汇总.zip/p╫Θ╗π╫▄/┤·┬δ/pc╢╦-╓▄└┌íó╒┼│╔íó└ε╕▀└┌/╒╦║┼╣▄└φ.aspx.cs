﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class 账号管理 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData(searchCon());
        }
    }
    private 账号 searchCon()
    {
        账号 obj = new 账号();
        obj.uno = TextBox1.Text.Trim();
        obj.uname = TextBox2.Text.Trim();
        obj.upassword = TextBox3.Text.Trim();
        return obj;
    }
    private void BindData(账号 obj)
    {
        DataTable dt = obj.selectDataTable(obj);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindData(searchCon());
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        BindData(searchCon());
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("账号管理.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("管理员界面.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("图片管理.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("登陆界面.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        string id = TextBox4.Text;
        string a = "delete from Users where eno='"+id+"'";
        string str_provider = "Provider=Microsoft.Jet.OLEDB.4.0;";
        string str_source = "Data Source=F:\\企业文档管理系统P组\\App_Data\\数据库.mdb";
        string str_connection = str_provider + str_source;
        OleDbConnection cnn = new OleDbConnection(str_connection);
        cnn.Open();
        OleDbCommand cmd = new OleDbCommand(a, cnn);
        cmd.ExecuteReader();
        cnn.Close();
        System.Web.HttpContext.Current.Response.Write("<script>alert('删除成功');</script>"); 
    }
}
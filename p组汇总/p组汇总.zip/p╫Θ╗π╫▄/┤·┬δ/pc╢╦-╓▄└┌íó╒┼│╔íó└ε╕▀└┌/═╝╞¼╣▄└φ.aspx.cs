﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData(searchCon());
        }
    }
    private 图片管理 searchCon()
    {
        图片管理 obj = new 图片管理();
        obj.doc_no = TextBox1.Text.Trim();
        obj.tno = TextBox2.Text.Trim();
        return obj;
    }
    private void BindData(图片管理 obj)
    {
        DataTable dt = obj.selectDataTable(obj);
        GridView2.DataSource = dt;
        GridView2.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        BindData(searchCon());
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        BindData(searchCon());
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string id = TextBox3.Text;
        int b = Convert.ToInt32(id);
        string a = "delete from T_imgs where img_id="+ b;
        string str_provider = "Provider=Microsoft.Jet.OLEDB.4.0;";
        string str_source = "Data Source=F:\\企业文档管理系统P组\\App_Data\\数据库.mdb";
        string str_connection = str_provider + str_source;
        OleDbConnection cnn = new OleDbConnection(str_connection);
        cnn.Open();
        OleDbCommand cmd = new OleDbCommand(a, cnn);
        cmd.ExecuteReader();
        cnn.Close();

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string a = TextBox4.Text;
        string b = TextBox5.Text;
        string str_provider = "Provider=Microsoft.Jet.OLEDB.4.0;";
        string str_source = "Data Source=F:\\企业文档管理系统P组\\App_Data\\数据库.mdb";
        string str_connection = str_provider + str_source;        
        OleDbConnection cnn = new OleDbConnection(str_connection);
        cnn.Open();
        for (int i = 0; i < Request.Files.Count; i++)
        {
            HttpPostedFile file = Request.Files[i];
            if (file.ContentLength > 0)
            {
                if (file.ContentType.Contains("image/"))
                {
                    using (System.Drawing.Image img = System.Drawing.Image.FromStream(file.InputStream))
                    {
                        string FileName = System.IO.Path.GetFileName(file.FileName);
                        string strij = "insert into T_imgs(doc_no,img_folder,page) values ('"+a+"','" + FileName + "','"+b+"')";
                        OleDbCommand cmnmd = new OleDbCommand(strij, cnn);
                        cmnmd.ExecuteNonQuery();
                        img.Save(Server.MapPath("./upload/" + FileName));
                        this.Image1.ImageUrl = "upload/" + FileName;
                    }
                }
                else
                {
                    Response.Write("<script>alert('该文件不是图片格式！');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('请选择要上传的图片');</script>");
            }

        }
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("账号管理.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("图片管理.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("管理员界面.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("登陆界面.aspx");
    }
}
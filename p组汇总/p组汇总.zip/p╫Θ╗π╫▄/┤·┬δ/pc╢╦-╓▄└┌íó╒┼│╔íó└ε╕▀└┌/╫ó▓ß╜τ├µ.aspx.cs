﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      //  System.Web.HttpContext.Current.Response.Write("<script>alert('dsdsd');</script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        注册类 obj = new 注册类();
        obj.username = TextBox3.Text;
        obj.userid = TextBox1.Text;
        obj.password = TextBox2.Text;
        if (obj.insert(obj))
        {
            System.Web.HttpContext.Current.Response.Write("<script>alert('dsdsd');</script>");
            Response.Redirect("登陆界面.aspx");
        }
        else System.Web.HttpContext.Current.Response.Write("<script>alert('注册失败，请重新注册');</script>"); 
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}
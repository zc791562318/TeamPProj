﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData(searchCon());
        }
    }
    private 查询 searchCon()
    {
        查询 obj = new 查询();
        obj.doc_no = TextBox2.Text.Trim();
        obj.doc_name = TextBox3.Text.Trim();
        obj.doc_date = TextBox5.Text.Trim();
        obj.doc_seid = TextBox4.Text.Trim();
        return obj;
    }
    private void BindData(查询 obj)
    {
        DataTable dt = obj.selectDataTable(obj);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindData(searchCon());
    }
    protected void AccessDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click2(object sender, EventArgs e)
    {
        BindData(searchCon());
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
      //  Response.Redirect("图书界面.aspx?name="+TextBox6.Text);
        Response.Write("<script>window.open('图书界面.aspx?name="+TextBox6.Text+"','_blank')</script>");
    }
}
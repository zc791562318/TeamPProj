﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

       
    }
    public string createHtmlStr()
    {
        string a = Request.QueryString["name"];
        string htmstr = "";
        string str_provider = "Provider=Microsoft.Jet.OLEDB.4.0;";
        string str_source = "Data Source=F:\\企业文档管理系统P组\\App_Data\\数据库.mdb";
        string str_connection = str_provider + str_source;
        string strimg = "select * from T_imgs where doc_no='" + a + "' order by page";
        OleDbConnection cnn = new OleDbConnection(str_connection);
        cnn.Open();
        OleDbCommand cmd = new OleDbCommand(strimg, cnn);
        OleDbDataReader datar;
        datar = cmd.ExecuteReader();
        int i = 1;
        while (datar.Read())
        {
            /*  string str = " <div class=\"fb7-cont-page-book\">"
                   + "    <div class=\"fb7-page-book\"> "
                   + "        <div class=\"fb7-meta\">  "
                   + "                <span class=\"fb7-num\">22</span> "
                   + "        </div> "
                   + "    </div>  "
                   + " </div> ";
              mydiv.Style.Add("background-image", "url(img/1.jpg)");
              mydiv.InnerHtml = str;*/
            string b = datar["page"].ToString();
            string str1 = "<div class=\"page\" style=\"background-image:url(upload/doc" + a + "-" + i + ".gif)\">";
            string str2="<div class=\"fb7-meta\">   ";
            string str3 = "<span class=\"fb7-num\">"+b+"</span>";
            string str4 = "</div>   ";
            string str5 = "</div>";
            string str = str1 + str2 + str3 + str4+ str5;
            htmstr += str;
            i++;
        }
        cnn.Close();
        return htmstr;
    }
}